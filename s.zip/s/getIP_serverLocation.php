<?php
$serverLoc="23.1167,113.2500";
?>